#include <stdio.h>
#include <stdlib.h>

// Define the structure for a node in the linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to insert a new node before the head
struct Node* insertBeforeHead(struct Node* head, int value) {
    // Allocate memory for the new node
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    
    // Check if memory allocation was successful
    if (newNode == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }
    
    // Assign data to the new node
    newNode->data = value;
    
    // Set the next pointer of the new node to point to the current head
    newNode->next = head;
    
    // Update the head to point to the new node
    head = newNode;
    
    // Return a reference to the new head of the list
    return head;
}

// Function to print the linked list
void printList(struct Node* head) {
    struct Node* current = head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

// Test the insertBeforeHead function
int main() {
    // Create an empty linked list
    struct Node* head = NULL;
    
    // Insert elements before the head
    head = insertBeforeHead(head, 10);
    head = insertBeforeHead(head, 20);
    head = insertBeforeHead(head, 30);
    
    // Print the linked list
    printf("Linked list after insertion: ");
    printList(head);
    
    return 0;
}
