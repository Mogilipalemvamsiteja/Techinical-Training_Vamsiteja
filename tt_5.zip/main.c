#include <stdio.h>
#include <stdlib.h>

// Structure to represent an edge in the graph
struct Edge {
    int src, dest, weight;
};

// Structure to represent a subset for union-find
struct Subset {
    int parent;
    int rank;
};

// Find operation for union-find
int find(struct Subset subsets[], int i) {
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}

// Union operation for union-find
void Union(struct Subset subsets[], int x, int y) {
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);
    
    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

// Comparison function for sorting edges by weight
int compare(const void* a, const void* b) {
    struct Edge* edge1 = (struct Edge*)a;
    struct Edge* edge2 = (struct Edge*)b;
    return edge1->weight - edge2->weight;
}

// Function to find the Really Special SubTree
int findReallySpecialSubTree(int V, int E, struct Edge* edges) {
    int totalWeight = 0;

    // Sort all the edges in non-decreasing order of their weight
    qsort(edges, E, sizeof(struct Edge), compare);

    // Allocate memory for creating V subsets
    struct Subset* subsets = (struct Subset*)malloc(V * sizeof(struct Subset));

    // Create V subsets with single elements
    for (int v = 0; v < V; v++) {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    int edgeCount = 0;
    int i = 0;  // Index variable for sorted edges
    while (edgeCount < V - 1 && i < E) {
        // Pick the smallest edge
        struct Edge nextEdge = edges[i++];

        // Find the subsets of the source and destination vertices
        int x = find(subsets, nextEdge.src);
        int y = find(subsets, nextEdge.dest);

        // If including this edge does not cause a cycle, include it in the result and increment the edge count
        if (x != y) {
            totalWeight += nextEdge.weight;
            Union(subsets, x, y);
            edgeCount++;
        }
    }

    free(subsets);
    return totalWeight;
}

int main() {
    int V = 3;  // Number of vertices
    int E = 3;  // Number of edges

    // Example edges
    struct Edge edges[] = { {0, 1, 2}, {1, 2, 3}, {2, 0, 5} };

    int weight = findReallySpecialSubTree(V, E, edges);
    printf("Overall weight of the Really Special SubTree: %d\n", weight);

    return 0;
}
